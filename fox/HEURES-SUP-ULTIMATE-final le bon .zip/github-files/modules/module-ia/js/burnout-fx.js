// ═══════════════════════════════════════════════════════════════
//  BURNOUT-FX.JS — Animations visuelles selon le niveau de risque
//  S'ajoute sans toucher aux fichiers existants
// ═══════════════════════════════════════════════════════════════

const BurnoutFX = {

  _injected: false,
  _currentLevel: 'sain',
  _loopId: null,
  _particles: [],

  // ── Point d'entrée principal ─────────────────────────────────
  update(score) {
    if (!this._injected) this._inject();
    const level = score < 20 ? 'sain'
                : score < 40 ? 'vigilance'
                : score < 60 ? 'risque'
                : score < 80 ? 'danger'
                :              'critique';

    if (level === this._currentLevel) return;
    this._currentLevel = level;
    this._applyLevel(level, score);
  },

  // ── Applique les effets selon le niveau ───────────────────────
  _applyLevel(level, score) {
    this._clearAll();
    document.body.dataset.burnoutLevel = level;

    switch (level) {
      case 'sain':      this._fxSain();      break;
      case 'vigilance': this._fxVigilance(); break;
      case 'risque':    this._fxRisque();    break;
      case 'danger':    this._fxDanger();    break;
      case 'critique':  this._fxCritique(score); break;
    }
  },

  // ── SAIN : légère lueur verte sur le fox ─────────────────────
  _fxSain() {
    const fox = document.getElementById('fox-sprite');
    if (fox) fox.style.filter = 'drop-shadow(0 0 8px #4CAF50)';
  },

  // ── VIGILANCE : pulsation orange douce ───────────────────────
  _fxVigilance() {
    this._addKeyframes('fx-pulse-orange', `
      0%,100% { box-shadow: 0 0 0px #FF8C42; }
      50%      { box-shadow: 0 0 18px #FF8C42; }
    `);
    const panel = document.querySelector('.character-panel') || document.querySelector('.main-panel');
    if (panel) panel.style.animation = 'fx-pulse-orange 2.5s ease-in-out infinite';

    this._showBanner('⚠️ Charge de travail élevée — restez vigilant', '#FF8C42');
  },

  // ── RISQUE : vignette rouge + tremblements légers ─────────────
  _fxRisque() {
    this._createVignette('#FF6B3540');

    this._addKeyframes('fx-shake-mild', `
      0%,100% { transform: translateX(0); }
      20%     { transform: translateX(-2px) rotate(-0.3deg); }
      40%     { transform: translateX(2px) rotate(0.3deg); }
      60%     { transform: translateX(-1px); }
      80%     { transform: translateX(1px); }
    `);
    document.body.style.animation = 'fx-shake-mild 4s ease-in-out infinite';

    this._startParticles('ember');
    this._showBanner('🔥 Zone de risque burn-out — ralentissez', '#FF6B35');
  },

  // ── DANGER : vignette pulsante rouge + distorsion + corde ─────
  _fxDanger() {
    this._createVignette('#E5393580', true); // pulsante

    this._addKeyframes('fx-vignette-pulse', `
      0%,100% { opacity: 0.5; }
      50%      { opacity: 0.85; }
    `);

    // Filtre CSS rouge sur tout l'écran
    document.documentElement.style.setProperty('--fx-tint', 'rgba(229,57,53,0.08)');
    this._createScreenTint();

    // Corde en bas de l'écran (noose hint)
    this._createRopeFX(false);

    this._startParticles('ash');
    this._showBanner('🚨 DANGER — Burn-out imminent. Agissez maintenant.', '#E53935', true);

    const fox = document.getElementById('fox-sprite');
    if (fox) {
      this._addKeyframes('fx-fox-worry', `
        0%,100% { transform: scale(1) rotate(0deg); }
        25%     { transform: scale(0.97) rotate(-2deg); }
        75%     { transform: scale(0.97) rotate(2deg); }
      `);
      fox.style.animation = 'fx-fox-worry 1.5s ease-in-out infinite';
    }
  },

  // ── CRITIQUE : effet noose complet + écran qui s'assombrit ────
  _fxCritique(score) {
    // Overlay sombre progressif
    this._createDarkOverlay(score);

    // La corde (noose) descend depuis le haut
    this._createRopeFX(true);

    // Filtre desaturé sur tout le body
    this._addKeyframes('fx-desaturate', `
      0%   { filter: saturate(1)   brightness(1); }
      100% { filter: saturate(0.3) brightness(0.85); }
    `);
    document.body.style.animation = 'fx-desaturate 3s ease forwards';

    // Texte qui tremble fort
    this._addKeyframes('fx-shake-hard', `
      0%,100% { transform: translate(0,0) rotate(0deg); }
      10%     { transform: translate(-3px,1px) rotate(-0.5deg); }
      20%     { transform: translate(3px,-1px) rotate(0.5deg); }
      30%     { transform: translate(-3px,0px) rotate(-0.3deg); }
      40%     { transform: translate(3px,2px) rotate(0.3deg); }
      50%     { transform: translate(-2px,-2px) rotate(-0.5deg); }
      60%     { transform: translate(2px,1px) rotate(0.5deg); }
      70%     { transform: translate(-2px,-1px) rotate(-0.3deg); }
      80%     { transform: translate(2px,0px) rotate(0deg); }
      90%     { transform: translate(-1px,1px) rotate(-0.2deg); }
    `);
    const header = document.querySelector('header');
    if (header) header.style.animation = 'fx-shake-hard 0.4s ease-in-out infinite';

    // Fox a l'air épuisé
    const fox = document.getElementById('fox-sprite');
    if (fox) {
      fox.style.filter = 'saturate(0.2) brightness(0.7) drop-shadow(0 0 12px #B71C1C)';
      fox.style.transform = 'rotate(-15deg) scale(0.9)';
      fox.style.transition = 'all 2s ease';
    }

    // Popup d'urgence après 1.5s
    setTimeout(() => this._showCritiquePopup(), 1500);

    this._startParticles('dark');
    this._showBanner('☠️ NIVEAU CRITIQUE — Votre santé est en danger réel', '#B71C1C', true);
  },

  // ── CORDE (noose) ────────────────────────────────────────────
  _createRopeFX(full) {
    const rope = document.createElement('div');
    rope.id = 'fx-rope';
    rope.innerHTML = `
      <svg width="80" height="${full ? 320 : 180}" viewBox="0 0 80 ${full ? 320 : 180}" 
           style="filter:drop-shadow(0 0 6px rgba(0,0,0,0.8))">
        <defs>
          <pattern id="ropePattern" x="0" y="0" width="8" height="8" patternUnits="userSpaceOnUse">
            <line x1="0" y1="0" x2="8" y2="8" stroke="#5D4037" stroke-width="2"/>
            <line x1="8" y1="0" x2="0" y2="8" stroke="#795548" stroke-width="1"/>
          </pattern>
        </defs>
        <!-- Corde verticale -->
        <rect x="36" y="0" width="8" height="${full ? 200 : 100}" fill="url(#ropePattern)" rx="4"/>
        ${full ? `
        <!-- Nœud coulant -->
        <ellipse cx="40" cy="230" rx="28" ry="18" fill="none" stroke="#5D4037" stroke-width="6"/>
        <path d="M 40 212 Q 50 220 56 235 Q 62 250 40 248 Q 18 250 24 235 Q 30 220 40 212" 
              fill="none" stroke="#795548" stroke-width="4"/>
        <ellipse cx="40" cy="248" rx="20" ry="12" fill="none" stroke="#5D4037" stroke-width="5"/>
        <!-- Ombre portée -->
        <ellipse cx="40" cy="295" rx="22" ry="5" fill="rgba(0,0,0,0.3)"/>
        ` : `
        <!-- Début du nœud seulement -->
        <path d="M 28 100 Q 40 108 52 100" fill="none" stroke="#5D4037" stroke-width="5"/>
        `}
      </svg>
    `;
    Object.assign(rope.style, {
      position: 'fixed',
      top: '0',
      right: full ? '12%' : '15%',
      zIndex: '8888',
      pointerEvents: 'none',
    });

    this._addKeyframes('fx-rope-swing', `
      0%,100% { transform: rotate(-3deg); transform-origin: 40px 0; }
      50%     { transform: rotate(3deg);  transform-origin: 40px 0; }
    `);
    rope.style.animation = `fx-rope-swing ${full ? 2 : 3}s ease-in-out infinite`;

    // Animation d'entrée : descend depuis le haut
    this._addKeyframes('fx-rope-drop', `
      from { transform: translateY(-100%) rotate(0deg); }
      to   { transform: translateY(0)    rotate(-3deg); }
    `);
    rope.style.animation = `fx-rope-drop 1.2s cubic-bezier(0.34,1.56,0.64,1) forwards, 
                             fx-rope-swing ${full ? 2 : 3}s ease-in-out 1.2s infinite`;

    document.body.appendChild(rope);
    this._particles.push(rope);
  },

  // ── Overlay sombre ────────────────────────────────────────────
  _createDarkOverlay(score) {
    const el = document.createElement('div');
    el.id = 'fx-dark-overlay';
    const opacity = Math.min(0.5, (score - 80) / 100);
    Object.assign(el.style, {
      position: 'fixed', inset: '0', zIndex: '7777',
      background: `radial-gradient(ellipse at center, transparent 30%, rgba(0,0,0,${opacity}) 100%)`,
      pointerEvents: 'none', transition: 'all 3s ease',
    });
    document.body.appendChild(el);
    this._particles.push(el);
  },

  // ── Vignette ──────────────────────────────────────────────────
  _createVignette(color, pulsing = false) {
    const el = document.createElement('div');
    el.id = 'fx-vignette';
    Object.assign(el.style, {
      position: 'fixed', inset: '0', zIndex: '7700', pointerEvents: 'none',
      background: `radial-gradient(ellipse at center, transparent 50%, ${color} 100%)`,
    });
    if (pulsing) {
      this._addKeyframes('fx-vignette-pulse', `
        0%,100% { opacity:0.6; } 50% { opacity:1; }
      `);
      el.style.animation = 'fx-vignette-pulse 2s ease-in-out infinite';
    }
    document.body.appendChild(el);
    this._particles.push(el);
  },

  // ── Teinte écran ──────────────────────────────────────────────
  _createScreenTint() {
    const el = document.createElement('div');
    el.id = 'fx-tint';
    Object.assign(el.style, {
      position: 'fixed', inset: '0', zIndex: '7600', pointerEvents: 'none',
      background: 'rgba(229,57,53,0.06)', mixBlendMode: 'multiply',
    });
    document.body.appendChild(el);
    this._particles.push(el);
  },

  // ── Particules (braises / cendres) ────────────────────────────
  _startParticles(type) {
    const canvas = document.createElement('canvas');
    canvas.id = 'fx-canvas';
    Object.assign(canvas.style, {
      position: 'fixed', inset: '0', zIndex: '7500',
      pointerEvents: 'none', width: '100vw', height: '100vh',
    });
    document.body.appendChild(canvas);
    this._particles.push(canvas);

    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
    const ctx     = canvas.getContext('2d');
    const pts     = [];

    const count = type === 'dark' ? 80 : type === 'ash' ? 50 : 30;
    const colors = type === 'ember' ? ['#FF8C42','#FF6B35','#FFD54F']
                 : type === 'ash'   ? ['#9E9E9E','#757575','#BDBDBD']
                 :                    ['#424242','#212121','#616161'];

    for (let i = 0; i < count; i++) {
      pts.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 3 + 1,
        vx: (Math.random() - 0.5) * 0.5,
        vy: type === 'dark' ? Math.random() * 0.3 : -Math.random() * 0.8 - 0.2,
        a: Math.random(),
        color: colors[Math.floor(Math.random() * colors.length)],
        life: Math.random(),
      });
    }

    const draw = () => {
      if (!canvas.isConnected) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      pts.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.life -= 0.003;
        if (p.life <= 0) {
          p.life = 1; p.x = Math.random() * canvas.width;
          p.y = type === 'dark' ? 0 : canvas.height;
        }
        ctx.globalAlpha = p.life * 0.7;
        ctx.fillStyle   = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });
      this._loopId = requestAnimationFrame(draw);
    };
    draw();
  },

  // ── Bandeau bas de page ───────────────────────────────────────
  _showBanner(msg, color, urgent = false) {
    const el = document.createElement('div');
    el.id = 'fx-banner';
    el.textContent = msg;
    Object.assign(el.style, {
      position: 'fixed', bottom: '60px', left: '50%',
      transform: 'translateX(-50%)',
      background: color, color: '#fff',
      padding: '10px 24px', borderRadius: '30px',
      fontWeight: 'bold', fontSize: '0.95em',
      zIndex: '9990', pointerEvents: 'none',
      boxShadow: `0 4px 20px ${color}99`,
      maxWidth: '90vw', textAlign: 'center',
    });
    if (urgent) {
      this._addKeyframes('fx-banner-urgent', `
        0%,100% { transform: translateX(-50%) scale(1); }
        50%      { transform: translateX(-50%) scale(1.04); }
      `);
      el.style.animation = 'fx-banner-urgent 1s ease-in-out infinite';
    }
    document.body.appendChild(el);
    this._particles.push(el);
  },

  // ── Popup urgence niveau critique ─────────────────────────────
  _showCritiquePopup() {
    if (document.getElementById('fx-critique-popup')) return;
    const popup = document.createElement('div');
    popup.id = 'fx-critique-popup';
    popup.innerHTML = `
      <div id="fx-critique-inner">
        <div style="font-size:3em;margin-bottom:12px;animation:fx-icon-pulse 0.8s ease-in-out infinite">☠️</div>
        <h2 style="color:#B71C1C;margin:0 0 8px">NIVEAU CRITIQUE</h2>
        <p style="margin:0 0 16px;color:#555;font-size:0.95em;line-height:1.5">
          Votre analyse indique un risque <strong>très élevé</strong> de burn-out.<br>
          Cette situation nécessite une action immédiate.
        </p>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
          <button onclick="document.getElementById('fx-critique-popup').remove()" 
                  style="background:#B71C1C;color:#fff;border:none;padding:10px 20px;
                         border-radius:20px;cursor:pointer;font-weight:bold;font-size:0.9em">
            🔍 Voir les scénarios d'aide
          </button>
          <button onclick="document.getElementById('fx-critique-popup').remove()"
                  style="background:#eee;border:none;padding:10px 20px;
                         border-radius:20px;cursor:pointer;font-size:0.9em">
            Plus tard
          </button>
        </div>
      </div>
    `;
    Object.assign(popup.style, {
      position: 'fixed', inset: '0', zIndex: '10000',
      background: 'rgba(0,0,0,0.75)', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
    });
    const inner = popup.querySelector('#fx-critique-inner');
    Object.assign(inner.style, {
      background: '#fff', borderRadius: '20px', padding: '32px',
      maxWidth: '360px', textAlign: 'center',
      boxShadow: '0 20px 60px rgba(183,28,28,0.4)',
      animation: 'fx-popup-appear 0.4s cubic-bezier(0.34,1.56,0.64,1)',
    });
    this._addKeyframes('fx-popup-appear', `
      from { transform:scale(0.5); opacity:0; }
      to   { transform:scale(1);   opacity:1; }
    `);
    this._addKeyframes('fx-icon-pulse', `
      0%,100% { transform:scale(1); } 50% { transform:scale(1.15); }
    `);
    document.body.appendChild(popup);
  },

  // ── Utilitaires ───────────────────────────────────────────────
  _inject() {
    // CSS global pour les niveaux
    const style = document.createElement('style');
    style.id = 'burnout-fx-css';
    style.textContent = `
      [data-burnout-level="critique"] .xp-bar-fill   { background: #B71C1C !important; }
      [data-burnout-level="danger"]   .xp-bar-fill   { background: #E53935 !important; }
      [data-burnout-level="risque"]   .xp-bar-fill   { background: #FF6B35 !important; }
      [data-burnout-level="vigilance"] .xp-bar-fill  { background: #FF8C42 !important; }
      [data-burnout-level="critique"] header h1      { color: #B71C1C !important; }
      [data-burnout-level="danger"]   header h1      { color: #E53935 !important; }
    `;
    document.head.appendChild(style);
    this._injected = true;
  },

  _addKeyframes(name, rules) {
    if (document.querySelector(`style[data-fx="${name}"]`)) return;
    const s = document.createElement('style');
    s.dataset.fx = name;
    s.textContent = `@keyframes ${name} { ${rules} }`;
    document.head.appendChild(s);
  },

  _clearAll() {
    if (this._loopId) { cancelAnimationFrame(this._loopId); this._loopId = null; }
    this._particles.forEach(el => el.remove && el.remove());
    this._particles = [];
    document.body.style.animation = '';
    document.body.style.filter    = '';
    document.documentElement.style.removeProperty('--fx-tint');
    const fox = document.getElementById('fox-sprite');
    if (fox) { fox.style.animation = ''; fox.style.filter = ''; fox.style.transform = ''; }
    const header = document.querySelector('header');
    if (header) header.style.animation = '';
  },
};

// Auto-update toutes les 30s si moduleReader est disponible
setInterval(() => {
  if (typeof moduleReader !== 'undefined' && moduleReader.getBurnoutScore) {
    const bs = moduleReader.getBurnoutScore();
    BurnoutFX.update(bs.score);
  }
}, 30000);

console.log('✅ BurnoutFX chargé — animations prêtes');
