// Voir inventory.js pour le code des milestones
